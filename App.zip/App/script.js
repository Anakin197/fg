const tips = [
    "شرب الماء بانتظام يحافظ على صحتك.",
    "تناول الخضروات والفواكه يوميًا.",
    "قم بممارسة الرياضة لمدة 30 دقيقة كل يوم.",
    "احصل على قسط كافٍ من النوم.",
    "تجنب الإجهاد الزائد وخصص وقتًا للاسترخاء.",
    "احرص على غسل يديك بانتظام.",
    "تأكد من زيارة الطبيب للفحوصات الدورية.",
];

document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const username = document.getElementById("username").value;
    const welcomeMessage = document.getElementById("welcomeMessage");
    const tipsSection = document.getElementById("tipsSection");
    const tipsList = document.getElementById("tipsList");

    // عرض رسالة ترحيب
    welcomeMessage.textContent = `أهلاً بك، ${username}!`;
    welcomeMessage.classList.remove("hidden");

    // إضافة النصائح الطبية إلى القائمة
    tips.forEach(tip => {
        const li = document.createElement("li");
        li.textContent = tip;
        tipsList.appendChild(li);
    });

    tipsSection.classList.remove("hidden"); // عرض قسم النصائح

    // مسح نموذج تسجيل الدخول
    document.getElementById("loginForm").reset();
});
